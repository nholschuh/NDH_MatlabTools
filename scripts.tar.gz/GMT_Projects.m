LastDir = pwd;

if exist('C:\Users\Nick\Dropbox\Linux\GMT','dir') == 7
		 cd C:\Users\Nick\Dropbox\Linux\GMT
end
if exist('/Users/Lionheart/Dropbox/Linux/GMT','dir') == 7
		 cd /Users/Lionheart/Dropbox/Linux/GMT
end
