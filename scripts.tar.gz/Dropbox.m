LastDir = pwd;

if exist('C:\Users\Nick\Dropbox\','dir') == 7
		 cd C:\Users\Nick\Dropbox\
end
if exist('/Users/Lionheart/Dropbox','dir') == 7
		 cd /Users/Lionheart/Dropbox
end