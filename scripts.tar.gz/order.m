function val = order(inp)
% Computes the order of magnitude of the input value

val=floor(log10(abs(inp)));

end