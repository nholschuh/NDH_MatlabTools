cair_import
cice = cair/sqrt(3.15);
