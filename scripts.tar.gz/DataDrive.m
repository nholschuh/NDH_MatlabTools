LastDir = pwd;

if exist('E:/Graduate_Work/Data','dir') == 7
		 cd E:/Graduate_Work/Data
end
if exist('D:/Graduate_Work/Data','dir') == 7
        cd D:/Graduate_Work/Data
end
if exist('F:/Graduate_Work/Data','dir') == 7
        cd F:/Graduate_Work/Data
end
if exist('G:/Graduate_Work/Data','dir') == 7
        cd G:/Graduate_Work/Data
end