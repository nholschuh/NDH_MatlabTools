function [data] = dlmread_ndh(filename,delimit_opt)
% (C) Nick Holschuh - UW - 2017 (Nick.Holschuh@gmail.com)
% Reads a text file created by dlmwrite_ndh
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The inputs are as follows:
%
% filename - the filename (including extension) to write to
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%

if exist('delimit_opt') == 0;
    delimit_opt = '\t';
end

temp = tdfread(filename);

field_names = fields(temp);
field_names{1} = field_names{1}(6:end);

if isstrprop(field_names{1}(1),'digit') == 1
    field_names = cell(1,length(field_names));
    for i = 1:length(field_names)
        field_names{i} = ['field_',num2str(i)];
    end
    in_data = dlmread(filename,delimit_opt,0,0);
else
   in_data = dlmread(filename,delimit_opt,1,0); 
end
    


data = struct();

for i = 1:length(field_names)
    eval_str = ['data.',field_names{i},' = in_data(:,',num2str(i),');'];
    eval(eval_str);
end

end
