LastDir = pwd;

if exist([OnePath,'Matlab_Code\NDH_Tools'],'dir') == 7
		cd_string = ['cd ''',OnePath,'Matlab_Code\NDH_Tools'''];
        eval(cd_string)
        clearvars cd_string
end



