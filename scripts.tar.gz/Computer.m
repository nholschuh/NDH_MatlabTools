LastDir = pwd;

if exist('C:\Users\Nick\Desktop\','dir') == 7
		 cd C:\Users\Nick\Desktop\
end
if exist('/Users/Lionheart/Desktop','dir') == 7
		 cd /Users/Lionheart/Desktop
end
		 
