function deg = rad2deg(rad)
% Converts radians into degrees.

deg = rad./(pi/180);

end