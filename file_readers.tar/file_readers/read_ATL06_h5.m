function [output]=read_ATL06_h5(h5_file,output_type)
% (C) Nick Holschuh - University of Washington - 2017 (Holschuh@uw.edu)
% This function reads in the ATL06 .h5 file produced through the NASA SDC
% system, using the land ice algorithm produced by Ben Smith
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% Inputs %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% h5_file - string containing either the local or full paht the ATL06 file
% output_type - a flag allowing you to choose from the following:
%     0: Full output, following the .h5 file structure [default]
%     1: Reduced output, containing only the surface heights + lat/lon
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% Outputs %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% output - structure containing the .h5 information
%       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%

if exist('output_type') == 0
    output_type = 0;
end

I=h5info(h5_file,'/');

%%%%%%%%%%%%%%% This extracts the attributs of the hd5 file itself, and
%%%%%%%%%%%%%%% saves it to the object GranuleMeta
for i = 1:length(I.Attributes)
    wrt_str = ['output.GranuleMeta.',I.Attributes(i).Name,' = I.Attributes(i).Value;'];
    eval(wrt_str)
end

%%%%%%%%%%%%%%% Here we start looping into the different groups, to save
%%%%%%%%%%%%%%% their attributes and values
for i = 1:length(I.Groups)
    
    %%%%% Get the path into the hd5 file and the name to save into the
    %%%%% matlab structure
    rn = I.Groups(i).Name;
    rn2 = strsplit(rn,'/');
    rn_str = ['rn3 = strcat('];
    for j = 1:length(rn2)
        rn_str = [rn_str,'''',rn2{j},''',''.'','];
    end
    rn_str = [rn_str(1:end-1),');'];
    eval(rn_str);
    
    %%%%% Loop through the attributes and save them into the meta
    %%%%% substructure
    for j = 1:length(I.Groups(i).Attributes)
        wrt_str = ['output',rn3,'Meta.',I.Groups(i).Attributes(j).Name,' = I.Groups(i).Attributes(j).Value;'];
        eval(wrt_str)
    end
    
    %%%%% Loop through the datasets for this group
    for j = 1:length(I.Groups(i).Datasets)
        wrt_str = ['output',rn3,I.Groups(i).Datasets(j).Name,' = h5read(h5_file,[''',rn,''',''/'',''',I.Groups(i).Datasets(j).Name,''']);'];
        eval(wrt_str)        
    end
    
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    %%%%% Loop into the subgroups
    for j = 1:length(I.Groups(i).Groups)
        %%%%% Get the new naming structure
        rn = I.Groups(i).Groups(j).Name;
        rn2 = strsplit(rn,'/');
        rn_str = ['rn3 = strcat('];
        for k = 1:length(rn2)
            rn_str = [rn_str,'''',rn2{k},''',''.'','];
        end
        rn_str = [rn_str(1:end-1),');'];
        eval(rn_str);
        
        %%%%% Loop through the attributes and save them into the meta
        %%%%% substructure
        for k = 1:length(I.Groups(i).Groups(j).Attributes)
            wrt_str = ['output',rn3,'Meta.',I.Groups(i).Groups(j).Attributes(k).Name,' = I.Groups(i).Groups(j).Attributes(k).Value;'];
            eval(wrt_str)
        end
        
        %%%%% Loop through the datasets for this group
        for k = 1:length(I.Groups(i).Groups(j).Datasets)
            wrt_str = ['output',rn3,I.Groups(i).Groups(j).Datasets(k).Name,' = h5read(h5_file,[''',rn,''',''/'',''',I.Groups(i).Groups(j).Datasets(k).Name,''']);'];
            eval(wrt_str)
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%% Loop into the subgroups one more time
        for k = 1:length(I.Groups(i).Groups(j).Groups)
            %%%%% Get the new naming structure
            rn = I.Groups(i).Groups(j).Groups(k).Name;
            rn2 = strsplit(rn,'/');
            rn_str = ['rn3 = strcat('];
            for l = 1:length(rn2)
                rn_str = [rn_str,'''',rn2{l},''',''.'','];
            end
            rn_str = [rn_str(1:end-1),');'];
            eval(rn_str);
            
            %%%%% Loop through the attributes and save them into the meta
            %%%%% substructure
            for l = 1:length(I.Groups(i).Groups(j).Groups(k).Attributes)
                if max(rn3 == '-') == 1
                    rn3(find(rn3 == '-')) = [];
                end
                wrt_str = ['output',rn3,'Meta.',I.Groups(i).Groups(j).Groups(k).Attributes(l).Name,' = I.Groups(i).Groups(j).Groups(k).Attributes(l).Value;'];
                eval(wrt_str)
            end
            
            %%%%% Loop through the datasets for this group
            for l = 1:length(I.Groups(i).Groups(j).Groups(k).Datasets)
                wrt_str = ['output',rn3,I.Groups(i).Groups(j).Groups(k).Datasets(l).Name,' = h5read(h5_file,[''',rn,''',''/'',''',I.Groups(i).Groups(j).Groups(k).Datasets(l).Name,''']);'];
                eval(wrt_str)
            end
            
        end
        
    end
    
end


%%%%%%%%%%%%%%%%%%%%%%% This pares down the data structure to just the
%%%%%%%%%%%%%%%%%%%%%%% critical values desired
if output_type == 1
    output = rmfield(output,{'GranuleMeta','METADATA','ancillary_data','orbit_info','quality_assessment'});
    fs = fieldnames(output);
    
    for i = 1:length(fs)
        subfs = fieldnames(eval(['output.',fs{i}]));
        add_str = ['output.',fs{i},'.h_li = output.',fs{i},'.land_ice_height.h_li;'];
        eval(add_str)
        add_str = ['output.',fs{i},'.latitude = output.',fs{i},'.land_ice_height.latitude;'];
        eval(add_str)
        add_str = ['output.',fs{i},'.longitude = output.',fs{i},'.land_ice_height.longitude;'];
        eval(add_str)
        
        rm_str = ['output.',fs{i},' = rmfield(output.',fs{i},',subfs);'];
        eval(rm_str)
        
    end
end
   

end

