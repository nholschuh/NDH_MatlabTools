function [output]=read_IceSAT_h5(h5_file,output_type,filt_ant1_gre2)
% (C) Nick Holschuh - University of Washington - 2017 (Holschuh@uw.edu)
% This function reads in the IceSAT .h5 file produced through the NASA SDC
% system, using the land ice algorithm produced by Ben Smith
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% Inputs %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% h5_file - string containing either the local or full paht the ATL06 file
% output_type - a flag allowing you to choose from the following:
%     0: Full output, following the .h5 file structure [default]
%     1: Reduced output, containing only the surface heights (corrected for
%     saturation), lat/lon, reflectivity, and quality flags
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% Outputs %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
% output - structure containing the .h5 information
%       
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%


I=h5info(h5_file,'/');

if exist('filt_ant1_gre2') == 0
    filt_ant1_gre2 = 0;
end


%%%%%%%%%%%%%%% This extracts the attributs of the hd5 file itself, and
%%%%%%%%%%%%%%% saves it to the object GranuleMeta
for i = 1:length(I.Attributes)
    wrt_str = ['output.GranuleMeta.',I.Attributes(i).Name,' = I.Attributes(i).Value;'];
    eval(wrt_str)
end

%%%%%%%%%%%%%%% Here we start looping into the different groups, to save
%%%%%%%%%%%%%%% their attributes and values
for i = 1:length(I.Groups)
    
    %%%%% Get the path into the hd5 file and the name to save into the
    %%%%% matlab structure
    rn = I.Groups(i).Name;
    rn2 = strsplit(rn,'/');
    rn_str = ['rn3 = strcat('];
    for j = 1:length(rn2)
        rn_str = [rn_str,'''',rn2{j},''',''.'','];
    end
    rn_str = [rn_str(1:end-1),');'];
    eval(rn_str);
    
    %%%%% Loop through the attributes and save them into the meta
    %%%%% substructure
    for j = 1:length(I.Groups(i).Attributes)
        wrt_str = ['output',rn3,'Meta.',I.Groups(i).Attributes(j).Name,' = I.Groups(i).Attributes(j).Value;'];
        eval(wrt_str)
    end
    
    %%%%% Loop through the datasets for this group
    for j = 1:length(I.Groups(i).Datasets)
        wrt_str = ['output',rn3,I.Groups(i).Datasets(j).Name,' = h5read(h5_file,[''',rn,''',''/'',''',I.Groups(i).Datasets(j).Name,''']);'];
        eval(wrt_str)        
    end
    
 %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%   
    %%%%% Loop into the subgroups
    for j = 1:length(I.Groups(i).Groups)
        %%%%% Get the new naming structure
        rn = I.Groups(i).Groups(j).Name;
        rn2 = strsplit(rn,'/');
        rn_str = ['rn3 = strcat('];
        for k = 1:length(rn2)
            rn_str = [rn_str,'''',rn2{k},''',''.'','];
        end
        rn_str = [rn_str(1:end-1),');'];
        eval(rn_str);
        
        %%%%% Loop through the attributes and save them into the meta
        %%%%% substructure
        for k = 1:length(I.Groups(i).Groups(j).Attributes)
            wrt_str = ['output',rn3,'Meta.',I.Groups(i).Groups(j).Attributes(k).Name,' = I.Groups(i).Groups(j).Attributes(k).Value;'];
            eval(wrt_str)
        end
        
        %%%%% Loop through the datasets for this group
        for k = 1:length(I.Groups(i).Groups(j).Datasets)
            wrt_str = ['output',rn3,I.Groups(i).Groups(j).Datasets(k).Name,' = h5read(h5_file,[''',rn,''',''/'',''',I.Groups(i).Groups(j).Datasets(k).Name,''']);'];
            eval(wrt_str)
        end
        
        %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
        %%%%% Loop into the subgroups one more time
        for k = 1:length(I.Groups(i).Groups(j).Groups)
            %%%%% Get the new naming structure
            rn = I.Groups(i).Groups(j).Groups(k).Name;
            rn2 = strsplit(rn,'/');
            rn_str = ['rn3 = strcat('];
            for l = 1:length(rn2)
                rn_str = [rn_str,'''',rn2{l},''',''.'','];
            end
            rn_str = [rn_str(1:end-1),');'];
            eval(rn_str);
            
            %%%%% Loop through the attributes and save them into the meta
            %%%%% substructure
            for l = 1:length(I.Groups(i).Groups(j).Groups(k).Attributes)
                if max(rn3 == '-') == 1
                    rn3(find(rn3 == '-')) = [];
                end
                wrt_str = ['output',rn3,'Meta.',I.Groups(i).Groups(j).Groups(k).Attributes(l).Name,' = I.Groups(i).Groups(j).Groups(k).Attributes(l).Value;'];
                eval(wrt_str)
            end
            
            %%%%% Loop through the datasets for this group
            for l = 1:length(I.Groups(i).Groups(j).Groups(k).Datasets)
                wrt_str = ['output',rn3,I.Groups(i).Groups(j).Groups(k).Datasets(l).Name,' = h5read(h5_file,[''',rn,''',''/'',''',I.Groups(i).Groups(j).Groups(k).Datasets(l).Name,''']);'];
                eval(wrt_str)
            end
            
        end
        
    end
end
    

%%%%%%%%%%%%%%%%%%%%%%% This pares down the data structure to just the
%%%%%%%%%%%%%%%%%%%%%%% critical values desired
if output_type == 1
    output = rmfield(output,{'GranuleMeta','METADATA','ANCILLARY_DATA','BROWSE','Data_1HZ'});
    fs = fieldnames(output);
    
        
        if filt_ant1_gre2 == 0
           keep_inds = find(output.Data_40HZ.Geolocation.d_lat > -90 & output.Data_40HZ.Geolocation.d_lat < 90 ...
               & output.Data_40HZ.Geolocation.d_lon >= 0 & output.Data_40HZ.Geolocation.d_lat <= 360);
        elseif filt_ant1_gre2 == 1
            keep_inds = find(output.Data_40HZ.Geolocation.d_lat > -90 & output.Data_40HZ.Geolocation.d_lat < -60 ...
               & output.Data_40HZ.Geolocation.d_lon >= 0 & output.Data_40HZ.Geolocation.d_lat <= 360);  
            [output.x output.y] = polarstereo_fwd(output.Data_40HZ.Geolocation.d_lat(keep_inds),output.Data_40HZ.Geolocation.d_lon(keep_inds));
           
        elseif filt_ant1_gre2 == 2
            keep_inds = find(output.Data_40HZ.Geolocation.d_lat > 60 & output.Data_40HZ.Geolocation.d_lat < 90 ...
               & output.Data_40HZ.Geolocation.d_lon >= 0 & output.Data_40HZ.Geolocation.d_lat <= 360);           
            [output.x output.y] = polarstereo_fwd(output.Data_40HZ.Geolocation.d_lat(keep_inds),output.Data_40HZ.Geolocation.d_lon(keep_inds));
        end
    
        subfs = fieldnames(eval(['output.Data_40HZ']));
        add_str = ['output.latitude = output.Data_40HZ.Geolocation.d_lat(keep_inds);'];
        eval(add_str)
        add_str = ['output.longitude = output.Data_40HZ.Geolocation.d_lon(keep_inds);'];
        eval(add_str)
        add_str = ['output.elevation = output.Data_40HZ.Elevation_Surfaces.d_elev(keep_inds) + output.Data_40HZ.Elevation_Corrections.d_satElevCorr(keep_inds);'];
        eval(add_str)
        add_str = ['output.reflectivity_uc = output.Data_40HZ.Reflectivity.d_reflctUC(keep_inds);'];
        eval(add_str)
        
        subfs2 = fieldnames(eval(['output.Data_40HZ.Quality']));
        for i = 2:length(subfs2)
            add_str = ['output.Data_40HZ.Quality.',subfs2{i},' = output.Data_40HZ.Quality.',subfs2{i},'(keep_inds);'];
            eval(add_str)            
        end
        
        add_str = ['output.quality_flags = output.Data_40HZ.Quality;'];   
        eval(add_str)
        add_str = ['output.date = datetime(2000,1,1)+seconds(output.Data_40HZ.DS_UTCTime_40(keep_inds));'];
        eval(add_str)
        
        rm_str = ['output = rmfield(output,''Data_40HZ'');'];
        eval(rm_str)
        

end
    
    
end