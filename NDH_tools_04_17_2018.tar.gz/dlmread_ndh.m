function [data] = dlmwrite_ndh(filename)
% (C) Nick Holschuh - UW - 2017 (Nick.Holschuh@gmail.com)
% Reads a text file created by dlmwrite_ndh
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The inputs are as follows:
%
% filename - the filename (including extension) to write to
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%

temp = tdfread(filename);

field_names = fields(temp);
field_names{1} = field_names{1}(7:end);
in_data = dlmread(filename,'\t',2,0);

data = struct();

for i = 1:length(field_names)
    eval_str = ['data.',field_names{i},' = in_data(:,',num2str(i),');'];
    eval(eval_str);
end

end
