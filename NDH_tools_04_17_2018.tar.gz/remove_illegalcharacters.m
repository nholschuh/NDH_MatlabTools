function outstring = remove_illegalcharacters(in_string);


illegal_chars = ['{}()\/ -,:;?'];
%illegal_chars = [':;?()'];
outstring = in_string;

for i = 1:length(illegal_chars)
    remove_ind = find(outstring == illegal_chars(i));
    outstring(remove_ind) = [];
end
    