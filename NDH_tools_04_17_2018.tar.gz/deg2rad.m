function rad = deg2rad(deg)
% Converts degrees into radians.

rad = (pi/180).*deg;

end