function [x y] = line_extend(x,y,front_extend,back_extend);
%% Extends a provided line by the distances provided;
debug = 0;
if debug == 1
    x = [1 2]';
    y = [1 4]';
    front_extend = 1;
    back_extend = 0.5;
    plot(x,y,'o-','Color','blue')
    hold all
end


slope1 = slopeintercept([x(1) y(1)],[x(2) y(2)]);
s1_u = [sqrt(1/(slope1^2+1)) slope1*sqrt(1/(slope1^2+1))];

slope2 = slopeintercept([x(end) y(end)],[x(end-1) y(end-1)]);
s2_u = [sqrt(1/(slope2^2+1)) slope2*sqrt(1/(slope2^2+1))];

if length(x(1,:)) > length(x(:,1))
    x = [x(1)+s1_u(1)*front_extend x x(end)-s2_u(1)*back_extend];
    y = [y(1)+s1_u(2)*front_extend y y(end)-s2_u(2)*back_extend];
else
    x = [x(1)+s1_u(1)*front_extend; x; x(end)-s2_u(1)*back_extend];
    y = [y(1)+s1_u(2)*front_extend; y; y(end)-s2_u(2)*back_extend];
end


if debug == 1
    plot(x,y,'o','Color','red','MarkerFaceColor','red')
end

end
