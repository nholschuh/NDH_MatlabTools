function [xs ys cs] = getlims();

xs = get(gca,'XLim');
ys = get(gca,'YLim');
cs = caxis;

end






