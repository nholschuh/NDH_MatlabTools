function delete_planes()
% Deletes the last line plotted
cds = get(gca,'Children');

for i = 1:length(cds)
    if length(cds(i).Type) == 7
        if min(cds(i).Type == 'surface') == 1
            delete(cds(i));
        end
    end
end

end