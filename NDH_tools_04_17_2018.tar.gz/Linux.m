LastDir = pwd;

if exist('C:\Users\Nick\Dropbox\Linux','dir') == 7
		 cd C:\Users\Nick\Dropbox\Linux
end
if exist('/Users/Lionheart/Dropbox/Linux','dir') == 7
		 cd /Users/Lionheart/Dropbox/Linux
end
