function dlmwrite_ndh(savename,mat_in,header)
% (C) Nick Holschuh - UW - 2017 (Nick.Holschuh@gmail.com)
% Writes out a text file with an appropriate header line
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The inputs are as follows:
%
% savename - the filename (including extension) to write to
% mat_in - the matrix containing data to write (can also take structure)
% header - a cell array, containing strings to use for header information
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%


if isstruct(mat_in) == 1
    temp_data = mat_in;
    header = fields(temp_data);
    mat_in = [];
    for i = 1:length(header)
        read_str = ['mat_in(:,',num2str(i),') = temp_data.',header{i},';'];
        eval(read_str);
    end
end

%%%%%%%%%%%%%% This adds in the header line if it is provided
if exist('header') == 1
    
    fid = fopen(savename, 'wt');
    write_str = ['> '];
    for i = 1:length(header)
        write_str = [write_str '%s\t'];
    end
    write_str(end-1:end) = '\n';
    
    %%%%%%%%%%% Add the header words to the first row
    fprintf_str = ['fprintf(fid, write_str,'];
    for i = 1:length(header)
        fprintf_str = [fprintf_str,'''',header{i},''','];
    end
    fprintf_str = [fprintf_str(1:end-1),');'];
    eval(fprintf_str);
    
    %%%%%%%%%%% Add line breaks to the second row
    fprintf_str = ['fprintf(fid, write_str,'];
    for i = 1:length(header)
        fprintf_str = [fprintf_str,'''',repmat('-',1,length(header{i})),''','];
    end
    fprintf_str = [fprintf_str(1:end-1),');'];
    eval(fprintf_str);
    
    
    fclose(fid);
end

%%%%%%%%%%%%% Add the data to subsequent rows
dlmwrite(savename,mat_in,'delimiter','\t','-append');