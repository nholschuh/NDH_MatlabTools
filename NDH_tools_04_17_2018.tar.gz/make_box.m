function out_box = make_box(input_line,r_or_l)
% (C) Nick Holschuh - UW - 2017 (Nick.Holschuh@gmail.com)
% Takes an input line and generates a box with that as one side.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% The inputs are as follows:
%
% input_line - 2x2 input line
% r_or_l - [0] = to the right, 1 = to the left
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%

if exist('r_or_l') == 0
    r_or_l = 0;
end

ol1 = make_ortholine(input_line,0,r_or_l);
ol2 = make_ortholine(flipud(ol1),0,r_or_l);
ol3 = make_ortholine(flipud(ol2),0,r_or_l);
ol4 = make_ortholine(flipud(ol3),0,r_or_l);

out_box = [input_line(1,:); ...
    ol1(2,:); ...
    ol2(2,:); ...
    ol3(2,:); ...
    ol4(2,:)];
end







