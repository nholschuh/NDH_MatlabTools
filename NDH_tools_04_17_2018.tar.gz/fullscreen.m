function fullscreen()

set(gcf, 'Position', get(0,'Screensize'))

end