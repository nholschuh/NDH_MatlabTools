function output = orthogonal_projection(points_in,line_in);
%%%% This function projects a point to its nearest position on a line.

v1 = line_in(2,:) - line_in(1,:);
v2 = points_in - line_in(1,:);

np = sum([v2.*(ones(length(points_in(:,1)),1)*v1)],2)/dot(v1,v1)*(v1);

output = np+line_in(1,:);

end

