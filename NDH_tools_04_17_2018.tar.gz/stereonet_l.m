function stereonet_l(trend,plunge,rad_deg)
% Plots the point of a vector on an equal angle stereonet

figure

if rad_deg == 1
    trend = deg2rad(trend);
    plunge = deg2rad(plunge);
end


R = 1;
rho1 = (R.*pi/4-((plunge)/2))/pi*4;

polarhg(trend,rho1,'tdir','ClockWise','linestyle','.','rlim',[0 1],'rtick',[ 1/3 2/3 ],'tstep',30,'torig','Up','color','blue');
hold all

set(findall(gcf, 'String', '1'),'String', ' 0^o ');
set(findall(gcf, 'String', '0.33333'),'String', ' 60^o ');
set(findall(gcf, 'String', '0.66667'),'String', ' 30^o ');
set(findall(gcf, 'String', '0.66667'),'String', ' 30^o ');
num2 = findall(gcf, 'String', '0');
set(num2(1),'String', ' temp');
num2 = findall(gcf, 'String', '0');
set(num2,'String', '  ');
num2 = findall(gcf, 'String', ' temp');
set(num2,'String', ' 90^o');

end