function plot_contouroutput(contour_out,plottype,linewidth)


%%%%%%%%%%%%%%% This portion finds the contourline breaks
break_points = 1;
if exist('linewidth') == 0
    linewidth = 1;
end

while break_points(end) < length(contour_out(1,:))
    break_points(end+1) = break_points(end)+contour_out(2,break_points(end))+1;
end

break_points = break_points(1:end-1);


if plottype == 0
    contour_out(:,break_points) = NaN;
    plot(contour_out(1,:),contour_out(2,:),'Color','black','LineWidth',linewidth)
elseif plottype == 1
    break_points(end+1) = length(contour_out(1,:))+1;
    
    for i = 1:length(break_points)-1;
        fill(contour_out(1,break_points(i)+1:break_points(i+1)-1), ...
            contour_out(2,break_points(i)+1:break_points(i+1)-1), ...
            [1 1 1],'FaceAlpha',0.5);
    end
end



